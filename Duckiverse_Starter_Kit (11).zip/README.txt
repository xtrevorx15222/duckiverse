DUCKIVERSE — FIRST VERSION

Open index.html in a browser to preview.

PUBLISH (GitHub Pages)
1. Create a free GitHub account if needed.
2. Create a new PUBLIC repository named duckiverse.
3. Choose Add file > Upload files and upload index.html from this folder.
4. Commit changes.
5. In repository Settings > Pages, set Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for the Pages site URL to appear. It should resemble:
   https://YOUR-USERNAME.github.io/duckiverse/
7. Open that URL in a browser to test.
8. Paste the HTTPS URL into DAKboard's Website/Embed block.
9. Verify it renders on the actual DAKboard display.

NOTES
- The widget checks the current date every 60 seconds and uses America/New_York time.
- Four story weeks are included, beginning November 2, 2026; then they repeat.
- The screen must remain online. DAKboard's embedding/refresh behavior must be tested.
- The code has no logins, personal family data, or tracking.
- GitHub Pages is PUBLIC. Do not add private calendars or personal information to this code.
- No keyboard is required on the Raspberry Pi for daily operation.
